package learn.teach.QnA;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;

import java.util.ArrayList;

/**
 * Created by luke on 9/1/16.
 */
public class MenuAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<MenuItem> dataSource;

    public MenuAdapter(Context context, ArrayList<MenuItem> dataSource) {
        this.context = context;
        this.dataSource = dataSource;
        inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return dataSource.size();
    }

    @Override
    public Object getItem(int i) {
        return dataSource.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View newView = inflater.inflate(R.layout.menu_list_layout, viewGroup, false);
        Button btn = (Button) newView.findViewById(R.id.menuItemButton);
        btn.setText(((MenuItem) getItem(i)).getText());
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MenuItem item = (MenuItem) getItem(i);
                Intent intent = new Intent(item.getContext(), item.getDestination());
                context.startActivity(intent);
                if (item.getFinish()) {
                    Activity activity = (Activity) context;
                    activity.finish();
                }
            }
        });
        return newView;
    }


}
