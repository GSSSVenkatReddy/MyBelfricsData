package learn.teach.QnA;

import android.app.Application;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

/**
 * Created by luke on 5/25/17.
 */

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        //Parse SDK stuff goes here
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                //.setDefaultFontPath("fonts/CormorantGaramond-Bold.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );
    }
}