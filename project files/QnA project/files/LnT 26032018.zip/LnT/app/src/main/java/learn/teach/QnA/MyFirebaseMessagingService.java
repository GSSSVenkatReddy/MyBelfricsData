package learn.teach.QnA;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        try {
            String from=remoteMessage.getFrom();
            String body="-";
            try{
            body=remoteMessage.getNotification().getBody();}catch(Exception exp){}
            //Displaying data in log
            //It is optional
            Log.d(TAG, "From:=> " + from);
            Log.d(TAG, "Notification Message Body: " + body);

            //int actionId = Integer.valueOf(remoteMessage.getData().get("objectId"));
            //Log.d("PushNotification", String.valueOf(actionId));
            //Calling method to generate notification
            sendNotification(from+":"+body, 1);//actionId);
            Toast.makeText(this, "::"+ from, Toast.LENGTH_SHORT).show();
        }
        catch(Exception exp) {}
    }

    //This method is only generating push notification
    //It is same as we did in earlier posts 
    private void sendNotification(String messageBody, int actionId) {
        Intent intent = new Intent(getApplicationContext(), AnswerDetails.class);
        intent.putExtra("actionId", actionId);
        int uniqueInt = (int) (System.currentTimeMillis() & 0xfffffff);
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), uniqueInt, intent,
                PendingIntent.FLAG_CANCEL_CURRENT);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("QnA Notification")
                .setContentText(messageBody)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(actionId, notificationBuilder.build());

    }
}