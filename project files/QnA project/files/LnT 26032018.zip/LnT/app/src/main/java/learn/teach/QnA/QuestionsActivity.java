package learn.teach.QnA;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.jaredrummler.materialspinner.MaterialSpinner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;


public class QuestionsActivity extends AppCompatActivity {

    private static final String TAG = "QuestionsActivity";
    String email;
    String token;
    SQLiteDatabase database;
    private MaterialSpinner spinner;
    private HashMap<String, String> spinnerHashMap = new HashMap<>();
    private String selectedCategory = "ALL";
    private QuestionAdapter questionAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);
        database = getBaseContext().openOrCreateDatabase("sqlite-Q-n-A.db", MODE_PRIVATE, null);
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.loadingQuestionsProgressBar);
        progressBar.setVisibility(View.VISIBLE);

        final String[] ITEMS = {"ALL", "Mechanical", "Civil", "ECE", "EEE", "CSE"};

        spinnerHashMap.put("ALL", "ALL");
        spinnerHashMap.put("Mechanical", "Mechanical");
        spinnerHashMap.put("Civil", "Civil");
        spinnerHashMap.put("ECE", "ECE");
        spinnerHashMap.put("EEE", "EEE");
        spinnerHashMap.put("CSE", "CSE");


        spinner = (MaterialSpinner) findViewById(R.id.spinner);
        spinner.setItems(ITEMS);
        final SharedPreferences sharedPref = getSharedPreferences("learn.teach.QnA", MODE_PRIVATE);
        spinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, Object item) {
                selectedCategory = spinnerHashMap.get(item);
                ListView questionListView1 = (ListView) findViewById(R.id.questionListView);
                 ArrayList<Question> questionList1 = new ArrayList<>();
                questionAdapter = new QuestionAdapter(QuestionsActivity.this, questionList1);
                questionListView1.setAdapter(questionAdapter);

                //Toast.makeText(QuestionsActivity.this, " sc:"+selectedCategory, Toast.LENGTH_SHORT).show();
                PopulateQuestionsActivity task = new PopulateQuestionsActivity();
                task.execute();
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putInt("posOfLastSelectedCategory", position);
                editor.commit();
            }
        });


        int previouslySelectedCategory = sharedPref.getInt("posOfLastSelectedCategory", 0);

        if(previouslySelectedCategory > 0){
            spinner.setSelectedIndex(previouslySelectedCategory);
            String item = ITEMS[previouslySelectedCategory];
            selectedCategory = spinnerHashMap.get(item);
        }

//        try {
//            getCredentials();
//            isloggedin=true;
//        }
//        catch (Exception exp)
//        {
//            isloggedin=false;
//            FloatingActionButton fab=(FloatingActionButton)findViewById(R.id.fab);
//            fab.setVisibility(View.INVISIBLE);
//        }


        PopulateQuestionsActivity task = new PopulateQuestionsActivity();
        task.execute();
    }

    public void getCredentials() {
        Cursor query = database.rawQuery("SELECT * FROM users", null);
        if (query.moveToFirst()) {
            email = query.getString(0);
            token = query.getString(1);
        } else {
            System.out.println("No token in database");
            return;
        }

    }


    boolean isloggedin=false;
    public JSONArray getQuestions() {

        HashMap<String, String> valuePairs = new HashMap<String, String>();
        //Toast.makeText(QuestionsActivity.this, selectedCategory, Toast.LENGTH_SHORT).show();
        //int i=0; if(i<1) return null;
        valuePairs.put("category", selectedCategory);
        valuePairs.put("token", token);
        valuePairs.put("email", "");
        //valuePairs.put("question_id", "3");
        HttpGetRequest get =
                new HttpGetRequest(Config.baseURL + "user/question.php", valuePairs);
        System.out.println(selectedCategory+"-"+email+" :respo:"+get.responseText);
        //Toast.makeText(QuestionsActivity.this, get.responseText, Toast.LENGTH_SHORT).show();
        if(!get.responseText.contains("Error"))
        try {
            JSONObject json = new JSONObject(get.responseText);
            System.out.println(json);
            try{
                return json.getJSONArray("questions");
            }
            catch (JSONException exc){
                new JSONArray();
            }

        } catch (Exception exc) {
            Log.d(TAG, "Response text: " + get.responseText+":"+exc.toString());
            exc.printStackTrace();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(QuestionsActivity.this,
                            Config.internetError, Toast.LENGTH_SHORT).show();
                }
            });

            return null;
        }
        return null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Intent intent = getIntent();
        startActivity(intent);
        PopulateQuestionsActivity task = new PopulateQuestionsActivity();
        task.execute();
    }

    @Override
    protected void onResume() {
        super.onResume();
        PopulateQuestionsActivity task = new PopulateQuestionsActivity();
        task.execute();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    public void showNewQuestionActivity(View view) {
        Intent intent = new Intent(this, NewQuestion.class);
        startActivity(intent);
    }

    private class PopulateQuestionsActivity extends AsyncTask{
        @Override
        protected Object doInBackground(Object[] objects) {

            //questionListView;
            final ListView questionListView = (ListView) findViewById(R.id.questionListView);

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ProgressBar progressBar = (ProgressBar) findViewById(R.id.loadingQuestionsProgressBar);
                    progressBar.setVisibility(View.VISIBLE);
                    questionListView.setVisibility(View.INVISIBLE);
                }
            });

            final ObjectWrapper<JSONArray> wrapper = new ObjectWrapper<>();
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    wrapper.setObject(getQuestions());
                }
            });
            thread.start();
            try {
                thread.join();
            } catch (Exception exc) {
                exc.printStackTrace();
            }

            //Toast.makeText(QuestionsActivity.this, " q "+isloggedin, Toast.LENGTH_SHORT).show();
            JSONArray questions = wrapper.getObject();
            try {
                //if(isloggedin)
                {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            questionListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                    Question item = (Question) questionListView.getAdapter().getItem(i);
                                    Intent intent = new Intent(getApplicationContext(), QuestionDetailsActivity.class);
                                    intent.putExtra("title", item.getTitle());
                                    intent.putExtra("text", item.getText());
                                    intent.putExtra("id", item.getId());
                                    intent.putExtra("userName", item.getAsker().getName());
                                    intent.putExtra("userId", item.getAsker().getId());
                                    intent.putExtra("category", item.getCategory());
                                    intent.putExtra("subcategory", item.getSubcategory());
                                    startActivity(intent);
                                }
                            });
                        }
                    });
                }
                final ArrayList<Question> questionList = new ArrayList<>();
                for (int counter = 0; counter < questions.length(); counter++) {
                    JSONObject questionJSON = questions.getJSONObject(counter);
                    int userId = questionJSON.getInt("user_id");

                    //JSONObject userJSON = questionJSON.getJSONObject("user");

                    JSONObject userJSON = questionJSON.getJSONArray("user").getJSONObject(0);

                    User user = new User(userJSON.getInt("id"), userJSON.getString("name"), userJSON.getString("email"));
                    //User user = new User(1, "zebra", "r");
                    Question question = new Question(
                            questionJSON.getInt("id"),
                            questionJSON.getString("title"),
                            questionJSON.getString("text"),
                            user,
                            questionJSON.getInt("likes"),
                            questionJSON.getInt("dislikes"),
                            questionJSON.getInt("score"),
                            questionJSON.getBoolean("ilike"),
                            questionJSON.getString("category"),
                            questionJSON.getString("subcategory")
                            );


                    questionList.add(question);
                }
                if (questionAdapter == null) {
                    questionAdapter = new QuestionAdapter(QuestionsActivity.this, questionList);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            questionListView.setAdapter(questionAdapter);
                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            questionAdapter.setData(questionList);
                        }
                    });
                }
            } catch (Exception exc) {
                exc.printStackTrace();

            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ProgressBar progressBar = (ProgressBar) findViewById(R.id.loadingQuestionsProgressBar);
                    progressBar.setVisibility(View.GONE);
                    questionListView.setVisibility(View.VISIBLE);
                }
            });
            return null;
        }
    }
}