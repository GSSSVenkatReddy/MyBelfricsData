package learn.teach.QnA;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import java.util.HashMap;

public class LogoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logout);
        SQLiteDatabase database = getBaseContext().openOrCreateDatabase("sqlite-Q-n-A.db", MODE_PRIVATE, null);
        try {
            Cursor query = database.rawQuery("SELECT * FROM users", null);
            if (query.moveToFirst()) {
                String email = query.getString(0);
                String token = query.getString(1);
                HashMap<String, String> valuePairs = new HashMap<String, String>();
                valuePairs.put("email", email);
                valuePairs.put("token", token);
                //HttpPostRequest post = new HttpPostRequest(Config.baseURL + "user/login/token/delete", valuePairs);
                if (true) {

                    database.execSQL("DROP TABLE IF EXISTS users");
                } else {
                    System.out.println("Error deleting login token");
                    //System.err.println(post.responseText);
                }
            } else {
                System.out.println("No token in database");
                return;
            }
        } catch (Exception exc) {
            exc.printStackTrace();
        } finally {
            goToLoginActivity();
        }
    }

    public void goToLoginActivity() {
        Intent intent = new Intent(LogoutActivity.this, LoginScreen.class);
        System.out.println("Switching!");
        startActivity(intent);
        finish();
    }
}
