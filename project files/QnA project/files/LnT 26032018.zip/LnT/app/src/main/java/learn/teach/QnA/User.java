package learn.teach.QnA;

import android.content.Context;
import android.widget.Toast;

import org.json.JSONObject;

/**
 * Created by luke on 9/1/16.
 */
public class User {
    int id = 0;
    String name = "";
    String email = "";

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public User() {
    }

    public User(final String url, Context context) {
        HttpGetRequest get = null;
        final ObjectWrapper wrapper = new ObjectWrapper(get);
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                wrapper.setObject(new HttpGetRequest(url));
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException exc) {

        }
        get = (HttpGetRequest) wrapper.getObject();
        if (get.code == 200) {
            try {
                JSONObject json = new JSONObject(get.responseText);
                id = json.getInt("id");
                name = json.getString("name");
                email = json.getString("email");
            } catch (Exception exc) {
                Toast.makeText(context, "An exception was raised while getting user information!", Toast.LENGTH_LONG).show();
            }
        } else if (get.code == 400) {
            System.out.println(get.responseText);
        } else {
            System.out.println("An error occurred while getting user information!");
            System.out.println(get.responseText);
        }
    }

    public User(int id, Context context) {
        this(Config.baseURL + "user/information/" + String.valueOf(id), context);
    }

    public User(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    public void copy(User obj) {
        setId(obj.getId());
        setEmail(obj.getEmail());
        setName(obj.getName());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
