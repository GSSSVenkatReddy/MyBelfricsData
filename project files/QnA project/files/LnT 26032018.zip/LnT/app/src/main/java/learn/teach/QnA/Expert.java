package learn.teach.QnA;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.mikepenz.fastadapter.items.AbstractItem;

import java.util.List;

/**
 * Created by luke on 5/24/17.
 */

public class Expert extends AbstractItem<Expert, Expert.ViewHolder> {
    public String name;
    public String expertise;
    public int id;
    //The viewHolder used for this item. This viewHolder is always reused by the RecyclerView so scrolling is blazing fast

    public Expert(String name, String expertise, int id) {
        this.name = name;
        this.id = id;
        this.expertise = expertise;
    }

    //The logic to bind your data to the view
    @Override
    public void bindView(ViewHolder viewHolder, List<Object> payloads) {
        //call super so the selection is already handled for you
        super.bindView(viewHolder, payloads);

        //bind our data
        //set the text for the name
        viewHolder.name.setText(name);
        viewHolder.expertise.setText(expertise);
    }

    @Override
    public int getType() {
        return id;
    }

    //Init the viewHolder for this Item
    @Override
    public ViewHolder getViewHolder(View v) {
        return new ViewHolder(v);
    }

    @Override
    public int getLayoutRes() {
        return R.layout.expert_list_item;
    }

    protected static class ViewHolder extends RecyclerView.ViewHolder {
        protected TextView name;
        protected TextView expertise;
        public ViewHolder(View view) {
            super(view);
            name = (TextView) view.findViewById(R.id.expertNameTextView);
            expertise = (TextView) view.findViewById(R.id.expertExpertiseTextView);
        }
    }
}
