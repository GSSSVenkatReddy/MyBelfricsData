package learn.teach.QnA;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class GoogleCalendarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_calendar);
        WebView view = (WebView) findViewById(R.id.calendarWebView);
        WebSettings webSettings = view.getSettings();
        webSettings.setJavaScriptEnabled(true);
        view.loadData("<iframe src=\"https://calendar.google.com/calendar/embed?src=QnA.tjl%40gmail.com&ctz=America/Jamaica\" style=\"border: 0\" width=\"100%\" height=\"100%\" frameborder=\"0\" scrolling=\"no\"></iframe>", "text/html", "UTF-8");
    }
}
