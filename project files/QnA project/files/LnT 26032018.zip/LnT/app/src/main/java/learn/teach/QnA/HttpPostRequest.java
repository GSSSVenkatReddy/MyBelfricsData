package learn.teach.QnA;

/**
 * Created by luke on 8/29/2016.
 */

import android.net.Uri;

import org.apache.http.NameValuePair;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Request.Builder;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;

public class HttpPostRequest {
    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");
    InputStream content;
    String responseText;
    int code;

    HttpPostRequest(String url, Map<String, String> valuePair) {
        try {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = new OkHttpClient.Builder().addInterceptor(logging).build();
            Uri uri = Uri.parse(url);


            HttpUrl.Builder httpUrlBuilder = new HttpUrl.Builder();
            httpUrlBuilder.host(uri.getHost());
            httpUrlBuilder.scheme(uri.getScheme());

            ArrayList<String> paths = new ArrayList<>(uri.getPathSegments());

            for (String path : paths) {
                httpUrlBuilder.addPathSegment(path);
            }

            Builder builder = new Request.Builder();

            FormBody.Builder formBuilder = new FormBody.Builder();

            ArrayList<NameValuePair> nameValuePairs = new ArrayList<>();
            for (Map.Entry<String, String> entry : valuePair.entrySet()) {
                formBuilder.add(entry.getKey(), entry.getValue());
            }
            builder.url(httpUrlBuilder.build());
            builder.post(formBuilder.build());
            Response response = client.newCall(builder.build()).execute();
            code = response.code();
            responseText = response.body().string();
            responseText = responseText != null ? responseText : "";

        } catch (Exception exc) {
            exc.printStackTrace();
            if (responseText != null) {
                System.out.println(responseText);
            }
        }

    }
}
