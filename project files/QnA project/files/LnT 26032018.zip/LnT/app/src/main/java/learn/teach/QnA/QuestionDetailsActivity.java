package learn.teach.QnA;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class QuestionDetailsActivity extends AppCompatActivity {
    SQLiteDatabase database;
    String email;
    String token;
    String status, ucategory, usubcategory;
    String qcategory, qsubcategory;
    int question_id;
    int user_id;

    int quserid=0;
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    public void getCredentials() {
        Cursor query = database.rawQuery("SELECT * FROM users", null);
        if (query.moveToFirst()) {
//database.execSQL("CREATE TABLE users(email TEXT, uid TEXT, category TEXT, subcategory TEXT, status TEXT, token TEXT)");
            email = query.getString(0);
            user_id = query.getInt(1);
            ucategory= query.getString(2);
            usubcategory = query.getString(3);
            status = query.getString(4);
            token= query.getString(5);

        } else {
            System.out.println("No token in dabase");
            return;
        }
        database.close();
    }

    public void createToastMessage(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        });

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_details);
        Intent intent = getIntent();
        database = getBaseContext().openOrCreateDatabase("sqlite-Q-n-A.db", MODE_PRIVATE, null);
        question_id = intent.getIntExtra("id", 0);
        populateWithQuestionDetails qTask = new populateWithQuestionDetails();
        qTask.execute();
        populateAnswerList();
        getCredentials();

        Toast.makeText(this, ":"+ucategory+","+intent.getStringExtra("category"), Toast.LENGTH_LONG).show();

        if(!ucategory.equals(intent.getStringExtra("category")))
        {
            ((Button)findViewById(R.id.submitAnswerButton)).setVisibility(View.INVISIBLE);
           ((EditText)findViewById(R.id.newAnswerText)).setVisibility(View.INVISIBLE);

        }

        if(!ucategory.equals(intent.getStringExtra("category")))
        {
            ((Button)findViewById(R.id.submitAnswerButton)).setVisibility(View.INVISIBLE);
            ((EditText)findViewById(R.id.newAnswerText)).setVisibility(View.INVISIBLE);

        }
    }

    public void startEditActivity(View view) {
        Intent intent = new Intent(this, EditQuestionActivity.class);
        Intent oldIntent = getIntent();
        intent.putExtra("title", oldIntent.getStringExtra("title"));
        intent.putExtra("text", oldIntent.getStringExtra("text"));
        intent.putExtra("userId", question_id);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }

    public void populateAnswerList() {
        try {
            Toast.makeText(this,
                    "ans "+"in --", Toast.LENGTH_SHORT).show();
            final LinearLayout answerLinearLayout =
                    (LinearLayout) findViewById(R.id.questionDetailsLinearLayout);
            JSONArray answers = getAnswers(question_id);
            ArrayList<Answer> answerList = new ArrayList<>();
            for (int counter = 0; counter < answers.length(); counter++) {
                JSONObject answerJSON = answers.getJSONObject(counter);
                System.out.println(answerJSON);

                int userId = answerJSON.getInt("user_id");
                Answer answer = new Answer(
                        answerJSON.getInt("id"),
                        answerJSON.getString("text"),
                        new User(userId, getApplicationContext()),
                        answerJSON.getInt("likes"),
                        answerJSON.getInt("dislikes"),
                        answerJSON.getInt("score"));

                answerList.add(answer);
            }
            System.out.println(answerList);
            final AnswerAdapter adapter = new AnswerAdapter(this, answerList);

            //answerLinearLayout

            ListView questionAnswersListView=
                    (ListView)findViewById(R.id.questionAnswersListView);
            questionAnswersListView.setAdapter(adapter);

            for (int counter = 0; counter < adapter.getCount(); counter++) {
                final int counter1 = counter;
                View view = adapter.getView(counter, null, null);

                Toast.makeText(this,
                        "ans "+"in --:"+counter, Toast.LENGTH_SHORT).show();

                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Answer answer = (Answer)adapter.getItem(counter1);
                        Intent intent = new Intent(getApplicationContext(), AnswerDetails.class);
                        intent.putExtra("answerId", answer.getId());
                        Log.d("PushNotification", "Answer being sent to answer details activity: " + answer.getId());
                        startActivityForResult(intent, 0);
                    }
                });
                answerLinearLayout.addView(view);
            }



        } catch (Exception exc) {
            Toast.makeText(this,
                    "ans "+"in "+exc.toString(), Toast.LENGTH_SHORT).show();
            exc.printStackTrace();
        }
    }



    public void createAnswer(View view) {
        EditText textEditText = (EditText) findViewById(R.id.newAnswerText);
        TextView statusText = (TextView) findViewById(R.id.answerStatusText);
        final ListView answerListView = (ListView) findViewById(R.id.questionAnswersListView);


        String textText = textEditText.getText().toString();

        HashMap<String, String> valuePairs = new HashMap<String, String>();
        valuePairs.put("email", email);
        valuePairs.put("token", token);
        valuePairs.put("text", textText);
        valuePairs.put("question_id", String.valueOf(question_id));

        HttpPostRequest post = new HttpPostRequest(
                Config.baseURL + "user/answeradd.php", valuePairs);
        if (post.code == 200 && post.responseText.contains("success")) {
            textEditText.setText("");
            createToastMessage("Success!");
            recreate();
        } else if (post.code == 400) {
            createToastMessage(post.responseText);
        } else {
            createToastMessage(Config.internetError);
            if (post.responseText != null) {
                System.out.println(post.responseText);
            }

        }
        try {
            JSONObject json = new JSONObject(post.responseText);
            statusText.setText(json.getString("errors"));
        } catch (Exception exc) {
            exc.printStackTrace();
        }


    }

    public JSONArray getAnswers(int id) {
        HashMap<String, String> valuePairs = new HashMap<String, String>();
        //Toast.makeText(QuestionsActivity.this, selectedCategory, Toast.LENGTH_SHORT).show();
        //int i=0; if(i<1) return null;
        valuePairs.put("qid", id+"");

        HttpGetRequest get = new HttpGetRequest(
                Config.baseURL + "user/answer.php", valuePairs);
        Toast.makeText(this, "after "+get.responseText, Toast.LENGTH_LONG).show();

        try {
            JSONObject json = new JSONObject(get.responseText);
            System.out.println(json);
            return json.getJSONArray("answers");

        } catch (Exception exc) {
            exc.printStackTrace();
            return null;
        }
    }

    private class populateWithQuestionDetails extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] params) {
            try {
                HttpGetRequest get = new HttpGetRequest(Config.baseURL + "question1.php?qid=" + String.valueOf(question_id) + "/");
                if (get.code == 200) {

                    final JSONObject json = new JSONObject(get.responseText);
                    System.out.println("JSON response: " + json);
                    final TextView titleTextView = (TextView) findViewById(R.id.questionDetailsTitleTextView);
                    final TextView textTextView = (TextView) findViewById(R.id.questionDetailsTextTextView);
                    final TextView questionAskerTextView = (TextView) findViewById(R.id.questionAskerTextView);
                    final User asker = new User();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                asker.copy(new User(Config.baseURL + "user/information/" +
                                        json.getInt("user_id"), getApplicationContext()));
                            } catch (Exception exc) {
                                exc.printStackTrace();
                            }
                        }
                    });
                    user_id = asker.getId();
                    quserid=user_id;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {

                                if(quserid==user_id)
                                {
                                    ((Button)findViewById(R.id.submitAnswerButton)).setVisibility(View.INVISIBLE);
                                    ((EditText)findViewById(R.id.newAnswerText)).setVisibility(View.INVISIBLE);
                                }
                                textTextView.setText(json.getString("text"));
                                titleTextView.setText(json.getString("title"));
                                questionAskerTextView.setText(asker.getName());
                            } catch (Exception exc) {
                                exc.printStackTrace();
                            }

                        }
                    });

                } else if (get.code == 400) {
                    createToastMessage(get.responseText);
                }
            } catch (Exception exc) {
                exc.printStackTrace();
            }

            final CheckIfEditableAsyncTask task = new CheckIfEditableAsyncTask();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    task.execute();
                }
            });


            return null;
        }
    }

    private class CheckIfEditableAsyncTask extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] params) {
            HashMap<String, String> valuePairs = new HashMap<String, String>();
            valuePairs.put("email", email);
            valuePairs.put("token", token);
            valuePairs.put("id", String.valueOf(question_id));
            final HttpGetRequest get = new HttpGetRequest(Config.baseURL + "question/edit/editable", valuePairs);
            final TextView editButton = (TextView) findViewById(R.id.editQuestionButton);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (get.code == 200) {
                        System.out.println("Showing edit button!");
                        editButton.setVisibility(View.VISIBLE);
                    }
                    }
            });
            return null;
        }
    }
}
