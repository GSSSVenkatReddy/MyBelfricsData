package learn.teach.QnA;

/**
 * Created by luke on 9/1/16.
 */
public class Question {
    int id;
    String title;
    String text;
    User asker;
    int likes;
    int dislikes;
    int score;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    String category;

    public String getSubcategory() {
        return subcategory;
    }

    public void setSubcategory(String subcategory) {
        this.subcategory = subcategory;
    }

    String subcategory;
    boolean userLiked = false;

    public Question(int id, String title, String text, User asker, int likes, int dislikes, int score, boolean userLiked, String category, String subcategory)
    {
        this.id = id;
        this.title = title;
        this.text = text;
        this.asker = asker;
        this.likes = likes;
        this.dislikes = dislikes;
        this.score = score;
        this.userLiked = userLiked;
        this.category = category;
        this.subcategory= subcategory;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public User getAsker() {
        return asker;
    }

    public void setAsker(User asker) {
        this.asker = asker;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public int getDislikes() {
        return dislikes;
    }

    public void setDislikes(int dislikes) {
        this.dislikes = dislikes;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public boolean isUserLiked() {
        return userLiked;
    }

    public void setUserLiked(boolean userLiked) {
        this.userLiked = userLiked;
    }
}
