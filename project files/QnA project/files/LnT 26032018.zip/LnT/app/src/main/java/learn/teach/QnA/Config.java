package learn.teach.QnA;

/**
 * Created by luke on 12/16/16.
 */

public class Config {
    //public static String baseURL = "https://dev-Q-n-A-server.herokuapp.com/";
    //public static String baseURL = "https://Q-n-A.lukecs.com/";
    public static String baseURL = "https://datapro.in/qna/";
    public static String internetError = "An unexpected error has occured! Please check your internet connection!";
    public static String email;
    public static String token;
    public static String uid;
    public static String category;
    public static String subcategory;
    public static String status;
}
