package learn.teach.QnA;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.mikepenz.fastadapter.FastAdapter;
import com.mikepenz.fastadapter.IAdapter;
import com.mikepenz.fastadapter.commons.adapters.FastItemAdapter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ExpertActivity extends AppCompatActivity {
    SQLiteDatabase database;
    String email;
    String token;
    int question_id;
    int asker_id;
    RecyclerView expertList;

    public void getCredentials() {
        Cursor query = database.rawQuery("SELECT * FROM users", null);
        if (query.moveToFirst()) {
            email = query.getString(0);
            token = query.getString(1);
        } else {
            System.out.println("No token in database");
            return;
        }
        database.close();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expert);
        Intent intent = getIntent();
        database = getBaseContext().openOrCreateDatabase("sqlite-Q-n-A.db", MODE_PRIVATE, null);
        question_id = intent.getIntExtra("question_id", 0);
        asker_id = intent.getIntExtra("asker_id", 0);
        expertList = (RecyclerView) findViewById(R.id.expertRecyclerView);
        expertList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        getCredentials();
        ExpertListPopulater populater = new ExpertListPopulater();
        populater.execute();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    private class ExpertListPopulater extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] objects) {

            final HttpGetRequest request = new HttpGetRequest(Config.baseURL + "user/experts");
            final ObjectWrapper<Integer> wrapper = new ObjectWrapper<>();
            wrapper.setObject(question_id);
            runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    try {
                        final FastItemAdapter adapter = new FastItemAdapter();
                        adapter.withSelectable(true);
                        adapter.withOnClickListener(new FastAdapter.OnClickListener<Expert>() {
                            @Override
                            public boolean onClick(View v, IAdapter<Expert> adapter, Expert item, int position) {
                                // Handle click here
                                HashMap<String, String> valuePairs = new HashMap<String, String>();
                                valuePairs.put("email", email);
                                valuePairs.put("token", token);
                                valuePairs.put("question_id", String.valueOf(wrapper.getObject()));
                                valuePairs.put("expert_id", String.valueOf(item.id));
                                HttpPostRequest request = new HttpPostRequest(Config.baseURL + "question/ask-expert", valuePairs);
                                if (request.code == 200) {
                                    Toast.makeText(ExpertActivity.this, "Successfully asked expert!", Toast.LENGTH_SHORT).show();
                                } else if (request.code == 400) {
                                    Toast.makeText(ExpertActivity.this, request.responseText, Toast.LENGTH_LONG).show();
                                } else {
                                    Toast.makeText(ExpertActivity.this, Config.internetError, Toast.LENGTH_SHORT).show();
                                }
                                return true;
                            }
                        });
                        if (request.code == 200) {
                            JSONArray json = new JSONArray(request.responseText);
                            for (int counter = 0; counter < json.length(); counter++) {
                                JSONObject expertJSON = json.getJSONObject(counter);
                                Expert expert = new Expert(expertJSON.getString("name"), expertJSON.getString("expertise"), expertJSON.getInt("id"));
                                adapter.add(expert);
                            }
                        }
                        expertList.setAdapter(adapter);
                    } catch (Exception exc) {
                        exc.printStackTrace();
                    }
                }
            });
            return null;
        }
    }
}
