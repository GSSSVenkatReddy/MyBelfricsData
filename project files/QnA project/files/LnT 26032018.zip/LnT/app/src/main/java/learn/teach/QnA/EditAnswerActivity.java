package learn.teach.QnA;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class EditAnswerActivity extends AppCompatActivity {
    SQLiteDatabase database;
    String email;
    String token;
    int answerId = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_answer);
        database = getBaseContext().openOrCreateDatabase("sqlite-Q-n-A.db", MODE_PRIVATE, null);
        EditText editAnswerText = (EditText) findViewById(R.id.editAnswerText);
        Intent intent = getIntent();
        editAnswerText.setText(intent.getStringExtra("answerText"));
        answerId = intent.getIntExtra("answerId", 0);
    }

    public void getCredentials() {
        Cursor query = database.rawQuery("SELECT * FROM users", null);
        if (query.moveToFirst()) {
            email = query.getString(0);
            token = query.getString(1);
        } else {
            System.out.println("No token in database");
            return;
        }

    }

    public void createToastMessage(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        });

    }

    public void editAnswer(View view) {
        EditText textEditText = (EditText) findViewById(R.id.editAnswerText);

        getCredentials();

        String textText = textEditText.getText().toString();

        HashMap<String, String> valuePairs = new HashMap<String, String>();
        valuePairs.put("email", email);
        valuePairs.put("token", token);
        valuePairs.put("text", textText);
        valuePairs.put("id", String.valueOf(answerId));

        HttpPostRequest post = new HttpPostRequest(Config.baseURL + "answer/edit", valuePairs);
        if (post.code == 200) {
            createToastMessage("Success!");
            finish();
        } else if (post.code == 400) {
            Toast.makeText(this, post.responseText, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "An unexpected error has occurred!", Toast.LENGTH_LONG).show();
            System.out.println(post.responseText);
        }
        database.close();

    }

    public void cancel(View view) {
        database.close();
        finish();
    }
}
