package learn.teach.QnA;

import android.app.Activity;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.firebase.messaging.FirebaseMessaging;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.util.HashMap;

public class RegistrationScreen extends Activity {
    ToggleButton tg1;
    MaterialSpinner spinnercat, spinnersubcat;
    private Activity activity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        activity = this;

        spinnersubcat = (MaterialSpinner) findViewById(R.id.spinnersubcat);
        spinnercat = (MaterialSpinner) findViewById(R.id.spinnermaincat);

        spinnercat.setItems("Mechanical", "Civil", "ECE", "EEE", "CSE");
        spinnersubcat.setItems("m1", "m2");

        spinnercat.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {
            @Override public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                Snackbar.make(view, "Clicked " + item, Snackbar.LENGTH_LONG).show();

                switch(item)
                {
                    case "Mechanical": spinnersubcat.setItems("m1", "m2"); break;
                    case "Civil": spinnersubcat.setItems("c1", "c2"); break;
                    case "ECE": spinnersubcat.setItems("e1", "e2"); break;
                    case "EEE": spinnersubcat.setItems("ee1", "ee2"); break;
                    case "CSE": spinnersubcat.setItems("cs1", "cs2"); break;
                }

            }
        });

        tg1=(ToggleButton)findViewById(R.id.toggleButton);
        tg1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if (tg1.isChecked()) {
                    spinnercat.setVisibility(View.VISIBLE);
                    spinnersubcat.setVisibility(View.VISIBLE);
                    //Toast.makeText(activity, "on", Toast.LENGTH_SHORT).show();
                } else {
                    spinnercat.setVisibility(View.INVISIBLE);
                    spinnersubcat.setVisibility(View.INVISIBLE);
                    //Toast.makeText(activity, "off", Toast.LENGTH_SHORT).show();
                }
            }
        });



        final TextView text = (TextView) findViewById(R.id.registrationStatus);
        Thread thread = new Thread(new Runnable() {

            public void run() {
                String textToSetForView = "";
                if (isConnected()) {
                    textToSetForView = "Connected";
                } else {
                    textToSetForView = "No Internet Connection";
                }
                final String textVal = textToSetForView;
                runOnUiThread(new Runnable() {

                    public void run() {
                        text.setText(textVal);
                    }
                });
            }
        });
        thread.start();
    }

    public boolean isConnected() {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Activity.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }

    public void showLoginScreen(View view) {
        Intent intent = new Intent(RegistrationScreen.this, LoginScreen.class);
        startActivity(intent);
        System.out.println("Switching to login screen");
    }

    public void createToastMessage(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        });

    }

    public void register(View view) {

        final String email = ((EditText) findViewById(R.id.emailAddressRegister)).getText().toString();
        final String pwd=((EditText) findViewById(R.id.passwordRegister)).getText().toString();

        if(email=="" || pwd=="")
        {
            Toast.makeText(activity, "plz enter email and pwd", Toast.LENGTH_SHORT).show();
            return;
        }
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                TextView text = ((TextView) findViewById(R.id.registrationStatus));
                final ProgressBar progressBar = (ProgressBar) findViewById(R.id.registrationProgressBar);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.VISIBLE);
                    }
                });
                try {
                    HashMap<String, String> valuePairs = new HashMap<>();
                    valuePairs.put("email", email);
                    valuePairs.put("password", pwd);
                    valuePairs.put("confirm_password", ((EditText) findViewById(R.id.confirmPasswordRegister)).getText().toString());
                    valuePairs.put("name", ((EditText) findViewById(R.id.nameRegister)).getText().toString());
                    if (tg1.isChecked())
                    {
                        valuePairs.put("category", ((MaterialSpinner) findViewById(R.id.spinnermaincat)).getText().toString());
                        valuePairs.put("subcategory", ((MaterialSpinner) findViewById(R.id.spinnersubcat)).getText().toString());
                        valuePairs.put("status", "expert");
                    }
                    else
                    {
                        valuePairs.put("category", "");
                        valuePairs.put("subcategory", "");
                        valuePairs.put("status", "student");
                    }
                    HttpPostRequest post = new HttpPostRequest(
                            Config.baseURL + "user/register.php", valuePairs);
                    if (post.code == 200) {
                        if(post.responseText.contains("success")) {
                            createToastMessage("Success! Please return to the login page and login." + post.responseText);
                            try
                            {
                                FirebaseMessaging.getInstance().subscribeToTopic(valuePairs.get("category"));
                            }
                            catch(Exception expp){
                                //Toast.makeText(activity, "err "+expp.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                            createToastMessage(post.responseText);
                    } else if (post.code == 400) {
                        createToastMessage(post.responseText);
                    }
                    else {
                        createToastMessage("An error occurred! Please try again.");
                    }

                }
                catch (Exception expp) {
                    expp.printStackTrace();
                    //createToastMessage(Config.internetError);
                }
                finally {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setVisibility(View.INVISIBLE);
                        }
                    });
                }
            }
        });
        thread.start();
    }
}
