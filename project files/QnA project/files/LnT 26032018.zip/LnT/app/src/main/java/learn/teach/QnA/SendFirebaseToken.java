package learn.teach.QnA;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import java.util.HashMap;

/**
 * Created by luke on 10/3/16.
 */

public class SendFirebaseToken extends AsyncTask {
    SQLiteDatabase database;
    String email;
    String token;
    int question_id;
    int user_id;
    Context context;

    public SendFirebaseToken(Context context) {
        super();
        this.context = context;
        try {
            getCredentials();
        } catch (Exception exc) {
            Log.d("PushNotification", exc.getMessage());
        }

    }

    public void getCredentials() {
        database = context.openOrCreateDatabase("sqlite-Q-n-A.db", Context.MODE_PRIVATE, null);
        Cursor query = database.rawQuery("SELECT * FROM users", null);
        if (query.moveToFirst()) {
            email = query.getString(0);
            token = query.getString(1);
        } else {
            System.out.println("No token in database");
            return;
        }
        database.close();
    }


    @Override
    protected Object doInBackground(Object[] objects) {
        try {
            String fireBaseToken = FirebaseInstanceId.getInstance().getToken();
            System.out.println("Token: " + fireBaseToken);
            HashMap<String, String> valuePairs = new HashMap<String, String>();
            valuePairs.put("email", email);
            valuePairs.put("token", token);
            valuePairs.put("firebase_token", fireBaseToken);


            HttpPostRequest post = new HttpPostRequest(Config.baseURL + "user/firebase_token.php", valuePairs);

            if (post.code == 200) {

            } else if (post.code == 400) {
                createToastMessage(post.responseText);
            } else {
                createToastMessage("An unexpected error has occurred!");
            }
        } catch (Exception exc) {

        }
        return null;
    }

    public void createToastMessage(final String message) {
        ((Activity) context).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, message, Toast.LENGTH_LONG).show();
            }
        });

    }
}