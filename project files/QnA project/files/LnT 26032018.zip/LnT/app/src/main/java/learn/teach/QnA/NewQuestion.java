package learn.teach.QnA;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;


public class NewQuestion extends AppCompatActivity {
    SQLiteDatabase database;
    String email;
    String token;
    private MaterialSpinner spinner;
    private HashMap<String, String> spinnerHashMap = new HashMap<>();
    private String selectedCategory = "Mechanical";
    private String selectedsubCategory = "m1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_question);
        database = getBaseContext().openOrCreateDatabase("sqlite-Q-n-A.db", MODE_PRIVATE, null);
//        final String[] ITEMS = {"Mechanical", "Civil", "ECE", "EEE", "CSE"};
//
//        spinnerHashMap.put("All Questions", "all");
//
//        spinnerHashMap.put("Mechanical", "Mechanical");
//        spinnerHashMap.put("Civil", "Civil");
//        spinnerHashMap.put("ECE", "ECE");
//        spinnerHashMap.put("EEE", "EEE");
//        spinnerHashMap.put("CSE", "CSE");


        //spinner = (MaterialSpinner) findViewById(R.id.spinner);
        //spinner.setItems(ITEMS);


        final MaterialSpinner spinnersubcat = (MaterialSpinner) findViewById(R.id.subcatspinner);
        MaterialSpinner spinnercat = (MaterialSpinner) findViewById(R.id.spinner);

        spinnercat.setItems("Mechanical", "Civil", "ECE", "EEE", "CSE");
        spinnersubcat.setItems("m1", "m2");

        spinnercat.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {
            @Override public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                Snackbar.make(view, "Clicked " + item, Snackbar.LENGTH_LONG).show();

                selectedCategory = item;
                Toast.makeText(NewQuestion.this, "i "+item, Toast.LENGTH_SHORT).show();
                switch(item)
                {
                    case "Mechanical": spinnersubcat.setItems("m1", "m2"); break;
                    case "Civil": spinnersubcat.setItems("c1", "c2"); break;
                    case "ECE": spinnersubcat.setItems("e1", "e2"); break;
                    case "EEE": spinnersubcat.setItems("ee1", "ee2"); break;
                    case "CSE": spinnersubcat.setItems("cs1", "cs2"); break;
                }

            }
        });

        spinnersubcat.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, Object item) {
                selectedsubCategory = item.toString();
            }
        });
    }
    String uid="1";

    public void getCredentials() {
        Cursor query = database.rawQuery("SELECT * FROM users", null);
        if (query.moveToFirst()) {
            email = query.getString(0);
            uid = query.getString(1);
            token = query.getString(5);
        } else {
            System.out.println("No token in database");
            return;
        }

    }

    public void createQuestion(View view) {
        EditText titleEditText = (EditText) findViewById(R.id.newQuestionTitle);
        EditText textEditText = (EditText) findViewById(R.id.newQuestionText);

        getCredentials();
        Toast.makeText(this, "uid:"+uid, Toast.LENGTH_SHORT).show();
        String titleText = titleEditText.getText().toString();
        String textText = textEditText.getText().toString();

        HashMap<String, String> valuePairs = new HashMap<String, String>();
        valuePairs.put("userid", uid); // todo: replace 1 with userid - vijay
        valuePairs.put("email", email);
        valuePairs.put("token", token);
        valuePairs.put("title", titleText);
        valuePairs.put("text", textText);
        valuePairs.put("category", selectedCategory);
        valuePairs.put("subcategory", "");// ((MaterialSpinner) findViewById(R.id.spinnersubcat)).getText().toString());

        HttpPostRequest post = new HttpPostRequest(Config.baseURL + "user/newquestion.php", valuePairs);
        Toast.makeText(this, "q done "+post.responseText, Toast.LENGTH_SHORT).show();

        if (post.code == 200 && post.responseText.contains("success")) {
            finish();
            try
            {

//                HashMap<String, String> valuePairs2 = new HashMap<String, String>();
//                valuePairs2.put("userid", "1");
//                valuePairs2.put("email", email);
//                valuePairs2.put("token", token);
//                valuePairs2.put("title", titleText);
//                valuePairs2.put("text", textText);
//                valuePairs2.put("category", selectedCategory);

                //HttpPostRequest post2 = new HttpPostRequest("", valuePairs);
                Toast.makeText(this, "q done "+post.responseText, Toast.LENGTH_SHORT).show();


                RequestQueue queue = Volley.newRequestQueue(NewQuestion.this);

//                String url ="https://gcm-http.googleapis.com/gcm/send";
//
//// Request a string response from the provided URL.
//                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
//                        new Response.Listener<String>() {
//                            @Override
//                            public void onResponse(String response) {
//                                // Display the first 500 characters of the response string.
//                                //mTextView.setText("Response is: "+ response.substring(0,500));
//                            }
//                        }, new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        //mTextView.setText("That didn't work!");
//                    }
//                });
//
//// Add the request to the RequestQueue.
//                queue.add(stringRequest);


                /*
                * https://gcm-http.googleapis.com/gcm/send
Content-Type:application/json
Authorization:key=AIzaSyZ-1u...0GBYzPu7Udno5aA

{
  "to": "/topics/foo-bar",
  "data": {
    "message": "This is a GCM Topic Message!",
   }
}

                * */

                System.out.println("before notify. ");

                FirebaseSendMessage.selectedCategory=selectedCategory;
                FirebaseSendMessage.qtitle=titleText;
                //FirebaseSendMessage.qno=titleText;
                new FirebaseSendMessage().sendRequest();

                System.out.println("after notify. ");

            }
            catch(Exception exp)
            {
                System.out.println("after notify "+exp.getMessage());
            }
        } else if (post.code == 400) {
            System.out.println("Error verifying login token");
            if (post.responseText != null)
            System.out.println(post.responseText);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(NewQuestion.this, "The question title and text cannot be empty.", Toast.LENGTH_SHORT).show();
                }
            });
        }
        else
            Toast.makeText(this, "q "+post.responseText, Toast.LENGTH_SHORT).show();
    }



    static class FirebaseSendMessage  extends AsyncTask<String, Integer, Double> {
        private final static String AUTH_KEY = "AAAAXfkHlpY:APA91bFAJ44D9guJ_hOzMPUM0l0TDsQuTJbw6dCeLOkpmbjcCzLNJaKdywId4tHoV99_O3J36vxgoMzc3ljuRqg9i_GluCD28o13huABX5qKlVeh0AoUoEQXw-fpB25W1BMs2o4FqGV9";

        public static String selectedCategory="";
        public static String qtitle="";
        private Exception exception;

        protected Double doInBackground(String... params) {
            try {
                sendRequest(params);
            } catch (Exception e) {
                this.exception = e;
            }
            return null;
        }

        protected void onPostExecute(Long l) {
            // TODO: check this.exception
            // TODO: do something with the feed
        }


        public void sendRequest(String... params) {
            try {
                String urlString = "https://fcm.googleapis.com/fcm/send";
                URL url = new URL(urlString);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setDoOutput(true);
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json");
                con.setRequestProperty("Authorization", "key=" + AUTH_KEY);

                String postJsonData = "{\"to\": \"/topics/"+selectedCategory+"\", \"data\": {\"message\": \"This is a "+selectedCategory+"("+qtitle+") QnA Topic Message!\"}}";
                con.setDoOutput(true);

                DataOutputStream wr = new DataOutputStream(con.getOutputStream());
                wr.writeBytes(postJsonData);
                wr.flush();
                wr.close();

                int responseCode = con.getResponseCode();
                System.out.println("POST Response Code :: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    System.out.println("succeeded");
                }
        /*InputStream is = con.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String line = null;
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }
        //con.disconnect();*/
            } catch (Exception e) {
                Log.d("exception thrown: ", e.toString());
            }
        }


    }

    public void cancel(View view) {
        finish();
    }
}
