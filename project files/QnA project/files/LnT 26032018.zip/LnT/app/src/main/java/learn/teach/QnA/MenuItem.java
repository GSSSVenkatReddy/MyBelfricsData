package learn.teach.QnA;

import android.content.Context;

/**
 * Created by luke on 9/1/16.
 */
public class MenuItem {
    private String text;
    private Class destination;
    private boolean finish = false;
    private Context context;

    public MenuItem(String text, Class destination) {
        this.text = text;
        this.destination = destination;
    }

    public MenuItem(String text, Class destination, boolean finish, Context context) {
        this.text = text;
        this.destination = destination;
        this.finish = finish;
        this.context = context;
    }

    public boolean getFinish() {
        return finish;
    }

    public void setFinish(boolean finish) {
        this.finish = finish;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Class getDestination() {
        return destination;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }
}
