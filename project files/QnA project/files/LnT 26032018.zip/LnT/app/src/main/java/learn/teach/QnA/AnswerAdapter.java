package learn.teach.QnA;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by luke on 9/10/16.
 */
public class AnswerAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Answer> dataSource;

    public AnswerAdapter(Context context, ArrayList<Answer> dataSource) {
        this.context = context;
        this.dataSource = dataSource;
        inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return dataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return dataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        View newView = inflater.inflate(R.layout.answer_list_layout, viewGroup, false);
        TextView text = (TextView) newView.findViewById(R.id.answerTextTextView);
        text.setText(((Answer) getItem(position)).getText());
        TextView answererName = (TextView) newView.findViewById(R.id.answererNameTextView);
        answererName.setText(((Answer) getItem(position)).getAnswerer().getName());
        return newView;
    }
}
