package learn.teach.QnA;

/**
 * Created by luke on 9/1/16.
 */
public class Comment {
    int id;
    String text;
    User commenter;

    public Comment(int id, String text, User commenter) {
        this.id = id;
        this.text = text;
        this.commenter = commenter;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public User getCommenter() {
        return commenter;
    }

    public void setCommenter(User commenter) {
        this.commenter = commenter;
    }
}
