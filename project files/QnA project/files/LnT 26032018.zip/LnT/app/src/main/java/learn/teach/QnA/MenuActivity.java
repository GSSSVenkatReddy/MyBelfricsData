package learn.teach.QnA;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Toast.makeText(this, "tk "+refreshedToken, Toast.LENGTH_LONG).show();
        System.out.println("tk "+refreshedToken);

        final ListView menuListView = (ListView) findViewById(R.id.menu_list);
        ArrayList<MenuItem> menuItems = new ArrayList<>();

//        ArrayList<String>imageURLList = new ArrayList<>();
//
//        HttpGetRequest get = new HttpGetRequest(Config.baseURL + "sagely_QnA/all");
//        SliderLayout slideShowView = (SliderLayout) findViewById(R.id.sagelyQnASlideshow);
//        try{
//            JSONArray json = new JSONArray(get.responseText);
//            for (int counter = 0; counter < json.length(); counter++) {
//                String sagelyQnAPath = (String) json.get(counter);
//                imageURLList.add(sagelyQnAPath);
//                TextSliderView textSliderView = new TextSliderView(this);
//                textSliderView.image(Config.baseURL + "sagely_QnA/" + sagelyQnAPath);
//                slideShowView.addSlider(textSliderView);
//
//            }
//            slideShowView.setIndicatorVisibility(PagerIndicator.IndicatorVisibility.Invisible);
//        } catch (Exception exc) {
//
//        }
//        slideShowView.setDuration(10000);
        menuItems.add(new MenuItem("Questions", QuestionsActivity.class, false, getApplicationContext()));
        menuItems.add(new MenuItem("Answers", QuestionsByMe.class, false, getApplicationContext()));
        menuItems.add(new MenuItem("UpdateProfile", ProfileActivity.class, false, getApplicationContext()));
        menuItems.add(new MenuItem("Logout", LogoutActivity.class, true, getApplicationContext()));

        System.out.println("Menu Items Added!");
        MenuAdapter menuAdapter = new MenuAdapter(this, menuItems);
        menuListView.setAdapter(menuAdapter);
    }
}
