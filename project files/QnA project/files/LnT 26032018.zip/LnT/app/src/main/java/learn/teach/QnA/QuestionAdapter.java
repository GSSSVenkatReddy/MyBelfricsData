package learn.teach.QnA;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.like.LikeButton;
import com.like.OnLikeListener;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by luke on 9/2/16.
 */
public class QuestionAdapter extends BaseAdapter {
    private static final String TAG = "QuestionAdapter";
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Question> dataSource;
    public QuestionAdapter(Context context, ArrayList<Question> dataSource) {
        this.context = context;
        this.dataSource = dataSource;
        inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void setData(ArrayList<Question> newDataSource) {
        dataSource.clear();
        notifyDataSetChanged();
        dataSource.addAll(newDataSource);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return dataSource.size();
    }

    @Override
    public Object getItem(int i) {
        return dataSource.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final Question question = dataSource.get(i);
        View newView = inflater.inflate(R.layout.question_list_layout, viewGroup, false);
        if (i == 0) {
            newView.setPadding(newView.getPaddingLeft(), 0, newView.getPaddingRight(), newView.getPaddingBottom());
        }
        TextView text = (TextView) newView.findViewById(R.id.questionTextTextView);
        text.setText(question.getText());
        TextView title = (TextView) newView.findViewById(R.id.questionTitleTextView);
        title.setText(question.getTitle());
        TextView asker = (TextView) newView.findViewById(R.id.questionAsker);
        asker.setText(question.getAsker().getName());
        LikeButton likeButton = (LikeButton) newView.findViewById(R.id.like_button);

        if(question.isUserLiked()){
            likeButton.setLiked(true);
        }
        else{
            likeButton.setLiked(false);
        }

        likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                likeButton.setEnabled(false);
                likeOrDislike(question.id, likeButton);
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                likeButton.setEnabled(false);
                likeOrDislike(question.id, likeButton);
            }
        });
        return newView;
    }

    private void likeOrDislike(final int id, final LikeButton likeButton){
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                String url = Config.baseURL + "question/like";
                HashMap<String, String>valuePairs = new HashMap<String, String>();
                valuePairs.put("email", Config.email);
                valuePairs.put("token", Config.token);
                valuePairs.put("question_id", String.valueOf(id));
                HttpPostRequest post = new HttpPostRequest(url, valuePairs);
                likeButton.setEnabled(true);
                Log.d(TAG, post.responseText);
            }
        });
        thread.start();

    }


}
