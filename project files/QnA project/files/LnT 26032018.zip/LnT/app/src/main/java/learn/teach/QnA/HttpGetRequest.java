package learn.teach.QnA;

/**
 * Created by luke on 8/29/2016.
 */

import android.net.Uri;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGetHC4;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.InputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;

public class HttpGetRequest {
    InputStream content;
    String responseText;
    int code;

    HttpGetRequest(String url) {
        try {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = new OkHttpClient.Builder().addInterceptor(logging).build();
            Uri uri = Uri.parse(url);
            HttpUrl.Builder httpUrlBuilder = new HttpUrl.Builder();
            httpUrlBuilder.host(uri.getHost());
            httpUrlBuilder.scheme(uri.getScheme());

            ArrayList<String> paths = new ArrayList<>(uri.getPathSegments());

            for (String path : paths) {
                httpUrlBuilder.addPathSegment(path);
            }

            Request.Builder builder = new Request.Builder();

            builder.url(httpUrlBuilder.build());
            Response response = client.newCall(builder.build()).execute();
            code = response.code();
            responseText = response.body().string();
            responseText = responseText != null ? responseText : "";
        } catch (Exception exc) {
            exc.printStackTrace();
        }

    }

    HttpGetRequest(String url, HashMap<String, String> valuePair) {
        try {
            URIBuilder uriBuilder = new URIBuilder(url);
            ArrayList<NameValuePair> nameValuePairs = new ArrayList<>();
            for (Map.Entry<String, String> entry : valuePair.entrySet()) {
                uriBuilder.addParameter(entry.getKey(), entry.getValue());
            }
            URI uri = uriBuilder.build();
            HttpClient client = new DefaultHttpClient();
            final HttpGetHC4 get = new HttpGetHC4(uri);
            String json = "";
            final HttpResponse response = client.execute(get);
            code = response.getStatusLine().getStatusCode();
            responseText = EntityUtils.toString(response.getEntity());
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }
}
