package learn.teach.QnA;

/**
 * Created by luke on 9/10/16.
 */
public class ObjectWrapper<T> {
    T object;

    public ObjectWrapper(T object) {
        this.object = object;
    }

    public ObjectWrapper() {
    }

    public T getObject() {
        return object;
    }

    public void setObject(T object) {
        this.object = object;
    }
}
