package learn.teach.QnA;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.messaging.FirebaseMessaging;

import java.io.InputStream;
import java.util.HashMap;

public class LoginScreen extends AppCompatActivity {
    final String TAG = "LoginScreen";
    SQLiteDatabase database;
    String email = "";
    String token = "";
    String status, category, subcategory;
    int question_id;
    int user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (getIntent().getExtras() != null) {
            for (String key : getIntent().getExtras().keySet()) {
                String value = getIntent().getExtras().getString(key);
                Log.d(TAG, "Key: " + key + " Value: " + value);
            }
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);


        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 8) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                    .permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        final TextView text = (TextView) findViewById(R.id.loginStatus);
        database = getBaseContext().openOrCreateDatabase("sqlite-Q-n-A.db", MODE_PRIVATE, null);
        //verifyTokenIfPresent();
        Thread thread = new Thread(new Runnable() {

            public void run() {
                String textToSetForView = "";
                if (isConnected()) {
                    textToSetForView = "Connected";
                } else {
                    textToSetForView = "No Internet Connection";
                }
                final String textVal = textToSetForView;
                runOnUiThread(new Runnable() {

                    public void run() {
                        text.setText(textVal);
                    }
                });
            }
        });
        thread.start();
    }

    public boolean isConnected() {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Activity.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }


    public void verifyTokenIfPresent() {
        try {
            Cursor query = database.rawQuery(
                    "SELECT * FROM users", null);
            if (query.moveToFirst()) {
                String email = query.getString(0);
                String uid = query.getString(1);
                String category = query.getString(2);
                String subcategory = query.getString(3);
                String status = query.getString(4);
                String token = query.getString(5);
                HashMap<String, String> valuePairs = new HashMap<String, String>();
                valuePairs.put("email", email);
                valuePairs.put("uid", uid);
                valuePairs.put("category", category);
                valuePairs.put("subcategory", subcategory);
                valuePairs.put("status", status);
                valuePairs.put("token", token);
                HttpPostRequest post = new HttpPostRequest(
                        Config.baseURL + "user/token.php", valuePairs);
                if (post.code == 200) {
                    if(post.responseText.contains("success")) {
                        Config.email = email;
                        Config.uid = uid;
                        Config.category= category;
                        Config.subcategory = subcategory;
                        Config.status = status;
                        Config.token = token;
                        System.out.println("here 1");
                        goToMenuActivity();
                    }
                    else
                        System.out.println("Error1 "+post.responseText);
                } else {
                    System.out.println("Error verifying login token");
                }
            } else {
                System.out.println("No token in database");
                return;
            }
        } catch (Exception exc) {
            //exc.printStackTrace();
            System.out.println("verify token: no user local tb");
        }

    }

    public void createToastMessage(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        });

    }

    public void login(View view) {

        final String email2 = ((EditText) findViewById(R.id.editText)).getText().toString();
        final String pwd=((EditText) findViewById(R.id.editText2)).getText().toString();

        if(email2.equals("") || pwd.equals(""))
        {
            Toast.makeText(this, "plz enter email and pwd", Toast.LENGTH_SHORT).show();
            return;
        }

        InputStream inStream = null;
        String result = "";
        final ProgressBar progressBar = (ProgressBar) findViewById(R.id.loginProgressBar);
        progressBar.setVisibility(View.VISIBLE);
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    HashMap<String, String> valuePairs = new HashMap<String, String>();
                    email = ((EditText) findViewById(R.id.editText)).getText().toString();
                    final String password = ((EditText) findViewById(R.id.editText2)).getText().toString();
if(email=="" || password=="")
    return;
                    final String Email = email;
                    valuePairs.put("email", email);
                    valuePairs.put("password", password);
                    final HttpPostRequest post =
                            new HttpPostRequest(Config.baseURL + "user/login.php", valuePairs);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            TextView text = (TextView) findViewById(R.id.loginStatus);
                            try {

                                //final JSONObject json = new JSONObject(post.responseText);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            createToastMessage(post.responseText);//.getString("status"));
                                        } catch (Exception exc) {
                                            exc.printStackTrace();
                                        }

                                        progressBar.setVisibility(View.INVISIBLE);
                                    }
                                });
                                if (post.code == 200 && post.responseText.contains("success")) {
                                    database.execSQL("DROP TABLE IF EXISTS users");
                                    database.execSQL("CREATE TABLE users(email TEXT, uid INTEGER, category TEXT, subcategory TEXT, status TEXT, token TEXT)");
                                    String[]values=post.responseText.split("-");
if(post.responseText.contains("student"))
{
    database.execSQL(
            "INSERT INTO users VALUES('" + email + "', '" +
                    values[1]+ "', '', '', 'student', '')");

}
else
{
    database.execSQL(
            "INSERT INTO users VALUES('" + email + "', '" +
                    values[1]+ "', '" +values[2]+ "', '" +
                    values[3]+ "', '" +values[4]+ "', '" +
                    values[5]+ "')");

    FirebaseMessaging.getInstance().subscribeToTopic(values[2]);
}


                                    goToMenuActivity();
                                }
                            } catch (Exception exc) {
                                text.setText("Error!!"+exc.toString());
                                exc.printStackTrace();
                                System.out.println("Response: " + post.responseText);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        progressBar.setVisibility(View.INVISIBLE);
                                    }
                                });
                            }
                        }
                    });

                } catch (Exception exc) {
                    System.out.println("Exception");
                    exc.printStackTrace();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(LoginScreen.this, Config.internetError, Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.INVISIBLE);
                        }
                    });
                }


            }

        });
        thread.start();


    }

    public void getCredentials() {
        database = openOrCreateDatabase("sqlite-Q-n-A.db", Context.MODE_PRIVATE, null);
        Cursor query = database.rawQuery("SELECT * FROM users", null);
        if (query.moveToFirst()) {
            email = query.getString(0);
            user_id = query.getInt(1);
            category= query.getString(2);
            subcategory = query.getString(3);
            status = query.getString(4);
            token= query.getString(5);
        } else {
            System.out.println("No token in database");
            return;
        }
        database.close();
    }

    public void showRegistrationActivity(View view) {
        Intent intent = new Intent(LoginScreen.this, RegistrationScreen.class);
        System.out.println("Switching!");
        startActivity(intent);
        finish();
    }
    public void showQuestionsActivity(View view) {
        Intent intent = new Intent(LoginScreen.this, QuestionsActivity.class);
        System.out.println("Switching!");
        startActivity(intent);
        finish();
    }

    public void goToMenuActivity() {
        try {
            /////////////SendFirebaseToken task = new SendFirebaseToken(
            ////////////        getApplicationContext());
            //////////////task.execute();
            Intent intent = new Intent(LoginScreen.this, MenuActivity.class);
            System.out.println("Switching!!");
            startActivity(intent);
            finish();
        }
        catch (Exception exc) {
            TextView text = (TextView) findViewById(R.id.loginStatus);
            text.setText("Error!"+exc.toString());
            exc.printStackTrace();
        }
    }
}