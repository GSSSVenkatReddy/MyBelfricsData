package learn.teach.QnA;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class EditQuestionActivity extends AppCompatActivity {
    SQLiteDatabase database;
    String email;
    String token;
    int userId;

    public void createToastMessage(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        });

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_question);
        database = getBaseContext().openOrCreateDatabase("sqlite-Q-n-A.db", MODE_PRIVATE, null);

        EditText titleEditText = (EditText) findViewById(R.id.editQuestionTitle);
        EditText textEditText = (EditText) findViewById(R.id.editQuestionText);

        Intent intent = getIntent();

        titleEditText.setText(intent.getStringExtra("title"));
        textEditText.setText(intent.getStringExtra("text"));
        userId = intent.getIntExtra("userId", 0);
    }

    public void getCredentials() {
        Cursor query = database.rawQuery("SELECT * FROM users", null);
        if (query.moveToFirst()) {
            email = query.getString(0);
            token = query.getString(1);
        } else {
            System.out.println("No token in database");
            return;
        }

    }

    public void editQuestion(View view) {
        EditText titleEditText = (EditText) findViewById(R.id.editQuestionTitle);
        EditText textEditText = (EditText) findViewById(R.id.editQuestionText);

        getCredentials();

        String titleText = titleEditText.getText().toString();
        String textText = textEditText.getText().toString();

        HashMap<String, String> valuePairs = new HashMap<String, String>();
        valuePairs.put("email", email);
        valuePairs.put("token", token);
        valuePairs.put("title", titleText);
        valuePairs.put("text", textText);
        valuePairs.put("id", String.valueOf(userId));

        HttpPostRequest post = new HttpPostRequest(Config.baseURL + "question/edit", valuePairs);
        if (post.code == 200) {
            createToastMessage("Success!");
            finish();
        } else if (post.code == 400) {
            Toast.makeText(this, post.responseText, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "An unexpected error has occurred!", Toast.LENGTH_LONG).show();
            System.out.println(post.responseText);
        }
        database.close();

    }

    public void cancel(View view) {
        database.close();
        finish();
    }
}
