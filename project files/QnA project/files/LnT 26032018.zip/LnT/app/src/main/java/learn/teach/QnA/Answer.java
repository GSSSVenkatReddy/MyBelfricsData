package learn.teach.QnA;

/**
 * Created by luke on 9/10/16.
 */
public class Answer {
    int id;
    String text;
    User answerer;
    int likes;
    int dislikes;
    int score;

    public Answer(int id, String text, User answerer, int likes, int dislikes, int score) {
        this.id = id;
        this.text = text;
        this.answerer = answerer;
        this.likes = likes;
        this.dislikes = dislikes;
        this.score = score;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public User getAnswerer() {
        return answerer;
    }

    public void setAnswerer(User answerer) {
        this.answerer = answerer;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public int getDislikes() {
        return dislikes;
    }

    public void setDislikes(int dislikes) {
        this.dislikes = dislikes;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
