package learn.teach.QnA;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class AnswerDetails extends AppCompatActivity {
    SQLiteDatabase database;
    int answerId;
    String email;
    String token;
    String answerText = "";

    public void getCredentials() {
        Cursor query = database.rawQuery("SELECT * FROM users", null);
        if (query.moveToFirst()) {
            email = query.getString(0);
            token = query.getString(1);
        } else {
            System.out.println("No token in database");
            return;
        }
        database.close();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        answerId = intent.getIntExtra("actionId", 0);
    }

    public void showEditAnswerActivity(View view) {
        Intent intent = new Intent(this, EditAnswerActivity.class);
        intent.putExtra("answerId", answerId);
        intent.putExtra("answerText", answerText);
        startActivityForResult(intent, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Intent intent = getIntent();
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer_details);
        database = getBaseContext().openOrCreateDatabase("sqlite-Q-n-A.db", MODE_PRIVATE, null);
        Intent intent = getIntent();

        Bundle extras = intent.getExtras();
        Log.d("PushNotification", "Extras: " + extras);
        answerId = extras.getInt("answerId");
        Log.d("PushNotification", "Extras after getting: " + extras);

        //Seems getting it the first time may not completely work.
        //getting it a second time will

        if (answerId == 0) {
            answerId = extras.getInt("actionId");
        }

        Log.d("PushNotification", "New answer id: " + answerId);

        GetAnswerDetails task = new GetAnswerDetails();

        getCredentials();
        CheckIfEditableAsyncTask task2 = new CheckIfEditableAsyncTask();

        GetAnswerComments task3 = new GetAnswerComments();

        ProgressBar bar = (ProgressBar) findViewById(R.id.getComments);
        bar.setVisibility(View.VISIBLE);

        RatingBar ratingbar=(RatingBar)findViewById(R.id.ratingbar);
        ratingbar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar1, float rating, boolean fromUser) {

                String rateValue = String.valueOf(ratingBar1.getRating());
                System.out.println("Rate for Module is"+rateValue);

                // send values to server
                HashMap<String, String> valuePairs = new HashMap<String, String>();
                valuePairs.put("aid", answerId+"");
                valuePairs.put("score", ratingBar1.getRating()+"");
                HttpPostRequest post = new HttpPostRequest(Config.baseURL + "user/answerupdate.php", valuePairs);
                if (post.code == 200) {
                } else if (post.code == 400) {
                    Toast.makeText(AnswerDetails.this, post.responseText, Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(AnswerDetails.this, "An unexpected error has occurred", Toast.LENGTH_LONG).show();
                    System.err.println(post.responseText);
                }
            }
        });

        task.execute();
        //task2.execute();
        //task3.execute();

        bar.setVisibility(View.INVISIBLE);
    }
    public void createToastMessage(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        });

    }

    public void createComment(View view) {
        EditText textEditText = (EditText) findViewById(R.id.newCommentText);
        String commentText = textEditText.getText().toString();
        HashMap<String, String> valuePairs = new HashMap<String, String>();
        valuePairs.put("email", email);
        valuePairs.put("token", token);
        valuePairs.put("text", commentText);
        valuePairs.put("answer_id", String.valueOf(answerId));

        HttpPostRequest post = new HttpPostRequest(Config.baseURL + "comment/add", valuePairs);
        if (post.code == 200) {
            textEditText.setText("");
            recreate();
        } else if (post.code == 400) {
            Toast.makeText(this, post.responseText, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "An unexpected error has occurred", Toast.LENGTH_LONG).show();
            System.err.println(post.responseText);
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    private class GetAnswerDetails extends AsyncTask{
        @Override
        protected Object doInBackground(Object[] objects) {
            Log.d("PushNotification", "answer id: " + answerId);
            HttpGetRequest get = new HttpGetRequest(Config.baseURL + "user/getanswer.php?aid=" + answerId);
            if(get.code == 200){
                try{
                    final TextView answerDetailTextView = (TextView)findViewById(R.id.answerDetailedTextView);
                    final RatingBar ratingBar= (RatingBar)findViewById(R.id.ratingbar);
                    final JSONObject json = new JSONObject(get.responseText);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try{
                                answerText = json.getString("text");
                                answerDetailTextView.setText(answerText);
                                try {
                                    ratingBar.setNumStars(Integer.parseInt(json.getString("score")));
                                }catch(Exception exp) {}
                            }
                            catch (Exception exc){
                                exc.printStackTrace();
                            }
                        }
                    });

                }
                catch(Exception exc){
                    exc.printStackTrace();
                }

            }
            else{
                if (get.responseText != null) {
                    createToastMessage(get.responseText);
                } else {
                    createToastMessage("There was an error loading the answer. Please check your internet and try again.");
                }

            }
            return null;
        }
    }

    private class CheckIfEditableAsyncTask extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] params) {
            HashMap<String, String> valuePairs = new HashMap<String, String>();
            valuePairs.put("email", email);
            valuePairs.put("token", token);
            valuePairs.put("id", String.valueOf(answerId));
            final HttpGetRequest get = new HttpGetRequest(Config.baseURL + "answer/edit/editable", valuePairs);
            final TextView editButton = (TextView) findViewById(R.id.editAnswerButton);
            if (get.responseText != null) {
                System.out.println(get.responseText);
            }

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (get.code == 200) {
                        System.out.println("Showing edit button!");
                        editButton.setVisibility(View.VISIBLE);
                    }
                }
            });

            return null;
        }
    }

    private class GetAnswerComments extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] objects) {
            final ProgressBar bar = (ProgressBar) findViewById(R.id.getComments);

            HttpGetRequest get = new HttpGetRequest(Config.baseURL + "answer/"
                    + String.valueOf(answerId) + "/comments");
            ArrayList<Comment> commentList = new ArrayList<>();
            if (get.code == 200) {
                final LinearLayout linearLayout = (LinearLayout) findViewById(R.id.answerDetailsLinearLayout);
                try {
                    JSONObject json = new JSONObject(get.responseText);
                    JSONArray jsonArray = json.getJSONArray("comments");
                    for (int counter = 0; counter < jsonArray.length(); counter++) {
                        JSONObject commentJSON = jsonArray.getJSONObject(counter);
                        Comment comment = new Comment(commentJSON.getInt("id"), commentJSON.getString("text"),
                                new User(commentJSON.getInt("user_id"), getApplicationContext()));
                        commentList.add(comment);
                    }
                    final CommentAdapter adapter = new CommentAdapter(AnswerDetails.this, commentList);
                    for (int counter = 0; counter < commentList.size(); counter++) {
                        final int counter1 = counter;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                View view = adapter.getView(counter1, null, null);
                                linearLayout.addView(view);
                            }
                        });

                    }
                } catch (JSONException exc) {
                    exc.printStackTrace();
                }

            } else if (get.code == 400) {
                if (get.responseText != null) {
                    createToastMessage(get.responseText);
                }

            } else {
                createToastMessage("An unexpected error has occurred while retrieving the comments!" +
                        " Please try again later.");
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    bar.setVisibility(View.GONE);
                }
            });
            return null;
        }
    }
}
